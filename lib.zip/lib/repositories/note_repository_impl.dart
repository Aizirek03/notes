import 'package:hive/hive.dart';
import 'package:notes/data/app_database.dart';

import '../models/note.dart';
import 'note_repository.dart';

class NoteRepositoryImpl
    implements NoteRepository {

  final AppDatabase database;

  NoteRepositoryImpl(this.database);

  @override
  Future<void> addNote(Note note) async {
    await database.noteBox.put(
      note.id,
      note,
    );
  }

  @override
  List<Note> getNotes() {
    return database.noteBox.values.toList();
  }

  @override
  Future<void> updateNote(Note note) async {
    await database.noteBox.put(
      note.id,
      note,
    );
  }

  @override
  Future<void> deleteNote(String id) async {
    await database.noteBox.delete(id);
  }
}

@override
Future<void> addNote(Note note, dynamic database) async {
  print('Добавляем заметку: ${note.title}');

  await database.noteBox.put(
    note.id,
    note,
  );

  print('Количество записей: ${database.noteBox.length}');
}